var searchData=
[
  ['sensitivity',['SENSITIVITY',['../classDJI_1_1onboardSDK_1_1Follow.html#a963f944b2aaf7b0719a29ee221a56d51',1,'DJI::onboardSDK::Follow']]],
  ['smoothmode',['SmoothMode',['../classDJI_1_1onboardSDK_1_1Flight.html#a2ba6b590d35f3a2d9c8fb737b5150454',1,'DJI::onboardSDK::Flight']]]
];
