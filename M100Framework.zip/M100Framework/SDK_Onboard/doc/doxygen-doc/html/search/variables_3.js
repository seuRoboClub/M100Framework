var searchData=
[
  ['devicestatus',['deviceStatus',['../structDJI_1_1onboardSDK_1_1CtrlInfoData.html#ade9507d21fa18fab2c2c265970272d90',1,'DJI::onboardSDK::CtrlInfoData']]]
];
